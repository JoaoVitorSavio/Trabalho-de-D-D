package com.example.teste

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.teste.ui.theme.TesteTheme
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : ComponentActivity() {

    private lateinit var apiService: ApiService // Declaração da variável para o serviço de API

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Criação da instância Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl("https://investidor10.com.br/") // Define a URL base da API
            .addConverterFactory(GsonConverterFactory.create()) // Adiciona o conversor Gson para manipular JSON
            .build()

        apiService = retrofit.create(ApiService::class.java) // Cria uma instância do serviço da API

        // Chame a função para obter os dados
        getStockData("VALE3") // Chama a função para buscar dados da ação "VALE3"

        setContent {
            TesteTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    private fun getStockData(stockCode: String) {
        // Faz a chamada à API de forma assíncrona
        apiService.getStockData(stockCode).enqueue(object : Callback<StockResponse> {
            override fun onResponse(call: Call<StockResponse>, response: Response<StockResponse>) {
                if (response.isSuccessful) {
                    val stockData = response.body() // Obtém os dados da resposta
                    // Manipule os dados recebidos aqui (por exemplo, atualizar a UI)
                    stockData?.let {
                        println("Preço: ${it.price}") // Imprime o preço da ação
                        println("Dividendos: ${it.dividends}") // Imprime a lista de dividendos
                    }
                } else {
                    println("Erro: ${response.errorBody()?.string()}") // Exibe mensagem de erro caso a resposta não seja bem-sucedida
                }
            }

            override fun onFailure(call: Call<StockResponse>, t: Throwable) {
                println("Falha: ${t.message}") // Exibe mensagem de falha em caso de erro na chamada
            }
        })
    }
}


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    TesteTheme {
        Greeting("Android")
    }
}
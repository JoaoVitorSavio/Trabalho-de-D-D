package com.example.teste

import retrofit2.http.GET
import retrofit2.http.Path

interface YourApiInterface {
    @GET("acao/{codigo}")
    suspend fun getAcao(@Path("codigo") codigo: String): AcaoResponse
}

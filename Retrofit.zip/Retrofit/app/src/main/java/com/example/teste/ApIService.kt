// ApiService.kt
package com.example.teste

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {
    @GET("https://investidor10.com.br/api/stock/VALE3")
    fun getStockData(@Path("VALE3") code: String): Call<StockResponse>
}

// Crie uma data class para armazenar a resposta
data class StockResponse(
    val price: Double, // ajuste os campos conforme a estrutura da resposta da API
    val dividends: List<Dividend>
)

data class Dividend(
    val date: String,
    val amount: Double
)

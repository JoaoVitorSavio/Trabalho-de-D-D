package com.example.teste

data class AcaoResponse(
    val valorCotacao: Double,
    val dividendos: List<Dividendo>
)

data class Dividendo(
    val data: String,
    val valor: Double
)

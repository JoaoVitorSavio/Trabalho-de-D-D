package up.ddm

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "atributos")
class Atributos {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    var pontos = 27

    fun adicionarPontos(nomeAtributo: String, valorAtual: Int, pontos: Int): Int {
    var pontosRestantesAtualizados = pontos
    println("Você tem $pontosRestantesAtualizados pontos restantes.")
    print("Quantos pontos deseja adicionar em $nomeAtributo? \n(Lembrando que você já começa com 8 em cada atributo e não pode ultrapassar 15 em nenhuma categoria, e a partir do nível 13 são gastos 2 pontos por nível em atributo)\n")

    val pontos = readLine()?.toIntOrNull()

    if (pontos == null) {
        println("Entrada inválida. Seus pontos estão vazios.")
        return adicionarPontos(nomeAtributo, valorAtual, pontosRestantesAtualizados)
    }

    var custoPontos = 0
    for (i in 1..pontos) {
        if (valorAtual + i > 13) {
            custoPontos += 2
        } else {
            custoPontos += 1
        }
    }

    // Verificar se o jogador pode gastar esses pontos
    if (custoPontos > pontosRestantesAtualizados) {
        println("Você não tem pontos suficientes. Tente novamente.")
        return adicionarPontos(nomeAtributo, valorAtual, pontosRestantesAtualizados)
    } else if (valorAtual + pontos > 15) {
        println("O máximo de pontos permitidos em cada atributo é 15. Tente novamente.")
        return adicionarPontos(nomeAtributo, valorAtual, pontosRestantesAtualizados)
    } else {
        println("Pontos inseridos no atributo $nomeAtributo.")
        pontosRestantesAtualizados -= custoPontos
    }

    return pontosRestantesAtualizados
}
}
